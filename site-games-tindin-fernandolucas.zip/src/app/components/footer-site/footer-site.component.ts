import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-site',
  templateUrl: './footer-site.component.html',
  styleUrls: ['./footer-site.component.css']
})
export class FooterSiteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
