import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-tindin',
  templateUrl: './login-tindin.component.html',
  styleUrls: ['./login-tindin.component.css']
})
export class LoginTindinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
