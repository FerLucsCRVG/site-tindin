import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-photo-main',
  templateUrl: './photo-main.component.html',
  styleUrls: ['./photo-main.component.css']
})
export class PhotoMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
