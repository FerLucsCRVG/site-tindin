import { Game } from "./game";

export interface ObjectTindin{
    games:Game[],
    totalSize?:number
}